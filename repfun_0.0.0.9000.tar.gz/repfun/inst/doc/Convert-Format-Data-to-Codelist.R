## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----built--------------------------------------------------------------------
message(paste0('Datetime: ',Sys.Date(),':',Sys.time()))

## ----setup, message=FALSE-----------------------------------------------------
library(repfun)

## ----define-------------------------------------------------------------------
repfun::rs_setup(R_RFMTDIR=paste0("../inst/formats"))

## ----makelist-----------------------------------------------------------------
list <- repfun::ru_data2codelist(rfenv$rfmtdata$formats())

## ----results------------------------------------------------------------------
message(paste0('First Code Value: ',list$SEXS$START[[1]])) # Code value 1
message(paste0('First Decode Value: ',list$SEXS$LABEL[[1]])) # Decode value 1
message(paste0('Second Code Value: ',list$SEXS$START[[2]])) # Code value 2
message(paste0('Second Decode Value: ',list$SEXS$LABEL[[2]])) # Decode value 2

