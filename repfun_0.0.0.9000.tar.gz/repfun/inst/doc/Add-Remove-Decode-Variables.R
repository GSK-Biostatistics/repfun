## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----built--------------------------------------------------------------------
message(paste0('Datetime: ',Sys.Date(),':',Sys.time()))

## ----setup--------------------------------------------------------------------
library(repfun)

## ----add----------------------------------------------------------------------
add_decode <- repfun::ru_groupbyvars(c("TRTCD", "TRTGRP", "ATOXGRN", "AEDECOD", "AEBODSYS"), 
                             c("TRTCD", "TRTGRP", "ATOXGRN", "ATOXGR"), TRUE)
print(add_decode)

## ----rem----------------------------------------------------------------------
rem_decode <- repfun::ru_groupbyvars(c("TRTCD", "TRTGRP", "ATOXGRN", "AEDECOD", "AEBODSYS"), 
                             c("TRTCD", "TRTGRP", "ATOXGRN", "ATOXGR"), FALSE)
print(rem_decode)

