## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----built--------------------------------------------------------------------
message(paste0('Datetime: ',Sys.Date(),':',Sys.time()))

## ----setup--------------------------------------------------------------------
library(repfun)

## ----contents2file------------------------------------------------------------
fnam <- paste0(base::tempdir(),"/test-ru_contents.txt")
sink(fnam)
  repfun::ru_contents(airquality)
sink()

## ----contents2out-------------------------------------------------------------
cat(readLines(fnam), sep = '\n')

