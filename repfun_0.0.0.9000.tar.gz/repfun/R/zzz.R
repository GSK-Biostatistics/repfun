.onLoad <- function(libname, pkgname) {

  #print(environment()) # For demonstration purposes only;
  #print(parent.env(environment())) # Don't really do this.
  #variable <- 42
  #assign("variable", variable, envir = parent.env(environment()))

  rfenv <<- new.env(parent = emptyenv())
  rfenv$G_DEBUG <- 0
  rfenv$PATH <- paste0("C:/Users/",Sys.getenv("USERNAME"),"/OneDrive - GSK/Documents/GitHub/repfun")
}
