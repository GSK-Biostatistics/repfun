<!-- BADGES & SHIELDS FROM https://naereen.github.io/badges/ -->

<a id="readme-top"></a>

[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

# R Reporting Functions Repository

This repository contains an R package of reporting functions that mimimc SAS macros for clinical reporting.  The package can be used to generate TLFs (Tables, Listings, Figures).  See several examples in the vignettes.

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<hr />

## How to Use This Repository

1. Download and install the package using the zip file on this site.
2. Load the library in an R session.
3. Review the function documentation under References.
3. Identify a use case that fits your needs from the Vignettes.
5. Copy and modify the Vignette code for your study.

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<hr />

## General Information

- This package contains reporting functions.
- View the function documentation at: https://glowing-adventure-mrjp2gp.pages.github.io/reference/index.html
- Install the package using: 
    library(remotes); install_github("gsk-tech/RepFuncs") [After setting user environment variable GITHUB_PAT.]
    or install.packages('/mnt/imported/code/repfun/repfun_0.0.0.9000.tar.gz',repos=NULL,type='source')
    or download the following zip file and install as above: https://github.com/gsk-tech/repfun/repfun_0.0.0.9000.tar.gz
- Use the package by loading it: library(repfun)
- View use cases at: https://glowing-adventure-mrjp2gp.pages.github.io/articles/

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<hr />

## Built With

* [![R](https://img.shields.io/badge/-script-276DC3.svg?style=flat&logo=R)](https://cran.r-project.org) 
* [![RStudio](https://img.shields.io/badge/RStudio-project-75AADB.svg?style=flat&logo=RStudio)](https://www.rstudio.com)
* [![RShiny](https://img.shields.io/badge/Shiny-shinyapps.io-447099"?style=flat&labelColor=white&logo=Posit&logoColor=447099")](https://shiny.posit.co/)
* [![python](https://img.shields.io/badge/Python-3.9-3776AB.svg?style=flat&logo=python&logoColor=white)](https://www.python.org)
* [![jupyter](https://img.shields.io/badge/Jupyter-Lab-F37626.svg?style=flat&logo=Jupyter)](https://jupyterlab.readthedocs.io/en/stable)
* [![PowerShell](https://img.shields.io/badge/PowerShell-%235391FE.svg?style=flat&logo=powershell&logoColor=white)](https://learn.microsoft.com/en-us/powershell/)
* [![Windows Terminal](https://img.shields.io/badge/Windows%20Terminal-%234D4D4D.svg?style=flat&logo=windows-terminal&logoColor=white)](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands)
* [![Google Chrome](https://img.shields.io/badge/Google%20Chrome-4285F4?style=flat&logo=GoogleChrome&logoColor=white)](https://www.google.com/chrome/)
* [![YouTube](https://img.shields.io/badge/YouTube-FF0000?style=flat&logo=youtube&logoColor=white)](https://www.youtube.com/)
* [![GitHub](https://img.shields.io/badge/GitHub-100000?style=flat&logo=github&logoColor=white)](https://github.com/)

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<hr />

## Getting Started

### Prerequisites

``` r
# Before using repfun, install the following R packages:
install.packages(c("tidyr","dplyr","ggplot2","magrittr","Hmisc","haven","stringr","admiral","lubridate","r2rtf")) 
```
<hr />

## License

This project is released under the MIT License. See the **[LICENSE](LICENSE.md)** file for details.

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<hr />

## Contact

For any questions or comments about this project, please contact **[Yongwei Wang](mailto:yongwei.x.wang@gsk.com?subject=[GitHub]%20Source%20Yongwei%20Wang)** or **[Chris Rook](mailto:christopher.x.rook@gsk.com?subject=[GitHub]%20Source%20Chris%20Rook)**.

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<hr />

## Acknowledgments

Acknowledgement to the following useful sources:

* [Helpful Read-Me Template](https://github.com/othneildrew/Best-README-Template)
* [Choose an Open Source License](https://choosealicense.com)
* [Img Shields](https://shields.io)
* [GitHub Pages](https://pages.github.com)
* [Font Awesome](https://fontawesome.com)
* [React Icons](https://react-icons.github.io/react-icons/search)

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<hr />
