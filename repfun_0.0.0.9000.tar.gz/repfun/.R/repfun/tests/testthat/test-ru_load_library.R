test_that("loading multiple libraries works", {

  suppressMessages(library(repfun))
  suppressMessages(library(testthat))

  repfun::setpath('/mnt/code/tests/testthat')

  lbs <- c("janitor", "gmodels", "epiR", "DescTools", "coin", "irr", "Exact", "stats")
  lbs <- c("stats","devtools")
  trashbin <- lapply(lbs, function(x) if (x %in% .packages()) {detach(paste0('package:',x), character.only=TRUE)})
  suppressMessages(repfun::ru_load_library(lbs))
  loaded <- lapply(lbs,function(x) x %in% loadedNamespaces())

  testthat::expect_equal(all(unlist(loaded)), TRUE)
})
