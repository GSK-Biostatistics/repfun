#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom rlang :=
## usethis namespace: end
NULL
