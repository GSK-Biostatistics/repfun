rfenv <- new.env(parent = emptyenv())
rfenv$G_DEBUG <- 0
rfenv$PATH <- paste0(getwd())
