# repfun 0.1.1

* Revised CRAN submission.

* FIXED Possibly misspelled words in DESCRIPTION

* FIXED Found the following (possibly) invalid file URI

* FIXED Flavor: r-devel-windows-x86_64. Check: tests, Result: ERROR

* FIXED Flavor: r-devel-linux-x86_64-debian-gcc, r-devel-windows-x86_64. Check: HTML version of manual, Result: NOTE

# repfun 0.1.0

* Initial CRAN submission.
