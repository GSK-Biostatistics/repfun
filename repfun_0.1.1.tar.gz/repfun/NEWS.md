# repfun 0.1.1

* Revised CRAN submission.

* FIXED Possibly misspelled words in DESCRIPTION

* FIXED Found the following (possibly) invalid file URI

* FIXED tests ERROR

* FIXED HTML NOTES

# repfun 0.1.0

* Initial CRAN submission.
